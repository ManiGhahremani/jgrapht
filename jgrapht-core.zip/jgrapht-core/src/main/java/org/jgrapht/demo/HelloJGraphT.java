/*
 * (C) Copyright 2003-2017, by Barak Naveh and Contributors.
 *
 * JGraphT : a free Java graph-theory library
 *
 * This program and the accompanying materials are dual-licensed under
 * either
 *
 * (a) the terms of the GNU Lesser General Public License version 2.1
 * as published by the Free Software Foundation, or (at your option) any
 * later version.
 *
 * or (per the licensee's choosing)
 *
 * (b) the terms of the Eclipse Public License v1.0 as published by
 * the Eclipse Foundation.
 */
package org.jgrapht.demo;

import java.net.*;

import org.jgrapht.*;
import org.jgrapht.graph.*;

import java.io.*;
import java.util.*;

import org.jgrapht.alg.CycleDetector;
import org.jgrapht.alg.cycle.HawickJamesSimpleCycles;

/**
 * A simple introduction to using JGraphT.
 *
 * @author Barak Naveh
 * @since Jul 27, 2003
 */
public final class HelloJGraphT
{
    private HelloJGraphT()
    {
    } // ensure non-instantiability.

    /**
     * The starting point for the demo.
     *
     * @param args ignored.
     */
    public static void main(String[] args)
    {
        CycleDetector<String, DefaultEdge> cycleDetector;
        
        for (String pathx: args) {
            DirectedGraph<String, DefaultEdge> graph = createGraph(pathx);
            System.out.println(graph.toString());
            cycleDetector = new CycleDetector<String, DefaultEdge>(graph);
            //long countCycles = cycleDetector.countSimpleCycles();
            //if(countCycles != 0){
            if(cycleDetector.detectCycles()){
            //System.out.println("contains " + countCycles + " simple cycle(s) as below:");
            //cycleDetector.printSimpleCycles();
                System.out.println("yes");
            }else{
            System.out.println("does not contain a simple cycle");
            }

            
        }
    }

    /**
     * Create a toy graph based on String objects.
     *
     * @return a graph based on String objects.
     */
    private static DirectedGraph<String, DefaultEdge> createGraph(String pathToGraph)
    {
        DirectedGraph<String, DefaultEdge> g = new SimpleDirectedGraph<>(DefaultEdge.class);
        try (BufferedReader reader =
             new BufferedReader(new FileReader(pathToGraph))) {
            String line = reader.readLine();
            int countLine = 0;
            countLine++;
            String VA = "";
            String VB = "";
            while(line !=null){
                for (int i = 0; i < line.length(); i++){
                    char c = line.charAt(i);
                    if( c == ' '){
                        //space seperator between each vertex in input
                        VA = line.substring(0, i);
                        VB = line.substring((i+1), line.length());
                        VB = VB.trim();
                        VA = VA.trim();
                        if( VA.length() != 0){
                            g.addVertex(VA);
                            g.addVertex(VB);
                            g.addEdge(VA, VB);

                        }else{
                            break;
                        }
                    }
                }
                line = reader.readLine();            }
        }
        
        catch(IOException e) {
            System.out.println("Problem reading file in readAGraph");
        }
        return g;
    }
}

