/*
 *
 */
package org.jgrapht.demo;

import java.net.*;

import org.jgrapht.*;
import org.jgrapht.graph.*;

import java.io.*;
import java.util.*;

import org.jgrapht.alg.shortestpath.DijkstraShortestPath;
import org.jgrapht.alg.NeighborIndex;
import org.jgrapht.alg.util.VertexDegreeComparator;
import org.jgrapht.alg.CliqueMinimalSeparatorDecomposition;
import org.jgrapht.demo.*;

import org.jgrapht.alg.cycle.*;
/**
 *
 */

public final class findcycles
{
    private static UndirectedGraph<String, DefaultEdge> graph;
    private static PatonCycleBase<String,DefaultEdge> cycleBases;
    //private static ArrayList<List<String>> ccs;
    
    
    private findcycles()
    {
    } // ensure non-instantiability.
    
    /**
     *
     */
    public static void main(String[] args)
    {
        List<List<String>> ccs = new ArrayList<List<String>>();
        String pathx= args[0];
        graph = createUndirGraph(pathx);
        //System.out.println(graph.toString());
        
        CliqueMinimalSeparatorDecomposition decomp = new CliqueMinimalSeparatorDecomposition(graph);
        Set<Set<String>> atoms = decomp.getAtoms();
        
        int countAtoms = 0;
        //optimally triangulate each atom
        for (Set atom: atoms){
            //Only perform the steps on atoms of size 4 and plus (as they would be cliques otherwise)
            //Conjecture
            if(atom.size() > 3){
                UndirectedSubgraph<String, DefaultEdge> atomSubgraph = new UndirectedSubgraph<String, DefaultEdge>(graph, atom);
                
                /**
                //print the subgraph regardless
                countAtoms ++;
                System.out.println("Subgraph number: " + countAtoms);
                System.out.println(atomSubgraph.toString());
                 **/
                
                Set <String> verticeSet = atomSubgraph.vertexSet();
                List<String> vertices = new ArrayList<String>(verticeSet);
                int V = vertices.size();
                NeighborIndex comp = new NeighborIndex(atomSubgraph);
                //test if the subgraph is a clique first.
                Boolean isClique = true;
                for (String v : verticeSet) {
                    List<String> neighborsOfv = comp.neighborListOf(v);
                    if(neighborsOfv.size() != atom.size()){
                        isClique = false;
                    }
                }
                //triangulate the chordless cycle(s) inside the atom optimally
                if(!isClique){
                    HashMap<String, String> chords = findcycles.triangulateChordlessCycles(atomSubgraph, vertices, V, comp);
                    //System.out.println("Chords for this subgraph are as below and added to the graph");
                    Set chordsset = chords.entrySet();
                    Iterator i = chordsset.iterator();
                    while(i.hasNext()) {
                        Map.Entry c = (Map.Entry)i.next();
                        String v1 = (String)c.getKey();
                        String v2 = (String)c.getValue();
                        graph.addEdge(v1, v2);
                        System.out.println(v1 + " " + v2);
                    }
                }else{//System.out.println("Subgraph was a clique and eliminated");
                }
                
            }
        }
        /**
        System.out.println("Triangulated graph as below:");
        System.out.println(graph.toString());
         **/
    }
    
    //Method that labels the graph by degree and finds the set of special non edges (triplets) that very least belong to a single chordless cycle
    //for each triplet it then finds the chordless cycle(s) and adds chords to the graph optimally respectively
    public static HashMap<String, String> triangulateChordlessCycles(UndirectedSubgraph<String, DefaultEdge> atomSubgraph, List<String> vertices, int V, NeighborIndex comp){
        HashMap<String, String> chords = new HashMap<>();
        PatonCycleBase<String, DefaultEdge> cycleBases = new PatonCycleBase<String, DefaultEdge>(atomSubgraph);
        List<List<String>> cList = new ArrayList<List<String>>();
        List<List<String>> targetList = new ArrayList<List<String>>();
        cList = cycleBases.findCycleBase();
        if(cList.size() == 1){
            CliqueMinimalSeparatorDecomposition minimalTriangulationFinder = new CliqueMinimalSeparatorDecomposition(atomSubgraph);
            chords = minimalTriangulationFinder.getChords();
        }
        else{
            int countUpperBound = 0;
            System.out.println("All cycles in cycle base are:");
            //print all cycles
            for(List<String> cycle: cList){
                System.out.println(cycle.toString());
            }
            //tirangulate with brute force
            /**
            for(List<String> cycle: cList){
                //theorem that the subgraph can be optimally triangulated only by optimally
                //triangulating each cycle of cycle basis and finding the optimal combination of
                //chords for the entire subgraph
                if(cycle.size() == 3){
                    //cycle is a triangle and can be triangulated with 0 chords
                    System.out.println("triangle inside the cycle basis is: " + cycle.toString());
                }else{
                    //build the list of chordless cycles of cycle basis
                    //NB no redundancies taked account for yet
                    targetList.add(cycle);
                    countUpperBound = countUpperBound + (cycle.size() - 3);
                }
            }
                int numberOfCCs = targetList.size();
                int countThisTriangulation = 0;
                int countBestTriangulation = countUpperBound;
                //update termination protocol

                List<List<HashMap<String, String>>> allPossibilities = new ArrayList<List<HashMap<String, String>>>(numberOfCCs);
                for(int i = 0; i < numberOfCCs; i++){
                    //cyclei of the complex sturcture to begin with
                    List<String> cyclei = targetList.get(i);
                    //find all possible optimal triangulations of it
                    List<HashMap<String, String>> PossibilitiesForCyclei = new ArrayList<HashMap<String, String>>();
                    PossibilitiesForCyclei = findcycles.findAllTriangulations(cyclei, atomSubgraph, PossibilitiesForCyclei);
                    allPossibilities.add(PossibilitiesForCyclei);
                }

             **/
        /**
        ArrayList<Integer> label = findcycles.label02(atomSubgraph,V, vertices);
        HashSet<Triplet<String, String, String>> tripletSet = findcycles.triplets(atomSubgraph, V, label, vertices, comp);
        if(tripletSet.size() == 1){
            System.out.println("Atom had a single triplet: Conjecture that atom only contains a single cc");
            //conjecture: if only one triplet exist, there must be only a single chordless cycle. thus the triangulation can be performed optimally in one run of the MCS algorithm.
            CliqueMinimalSeparatorDecomposition minimalTriangulationFinder = new CliqueMinimalSeparatorDecomposition(atomSubgraph);
            if(minimalTriangulationFinder.isChordal()){
                System.out.println("By the conjecture the subgraph is never chordal");
            }
            chords = minimalTriangulationFinder.getChords();
        }else{
            //there is atleast 3 intertwined chordless cycles in this subgraph and thus the optimal triangulation should be found by
            //trying different combinations of optimal triangulations for each, and choosing one combination that shares the most chords between them.
            System.out.println("This atom contained intertwined ccs and is not triangulated yet");
            List<List<String>> ccs = findcycles.findChordlessCycles(atomSubgraph, label, vertices, V, comp, tripletSet);
             System.out.println("ccs are as below for this complex struc: ");
             for(List<String> cycle : ccs){
             System.out.println(cycle);
             }
         }
         **/
        }
        return chords;
    }
    
    public static int catalan(int n) {
        int res = 0;
        // Base case
        if (n <= 1) {
            return 1;
        }
        for (int i = 0; i < n; i++) {
            res += catalan(i) * catalan(n - i - 1);
        }
        return res;
    }
    
    public static List<HashMap<String, String>> findAllTriangulations(List<String> cyclei, UndirectedSubgraph<String, DefaultEdge> atomSubgraph, List<HashMap<String, String>> PossibilitiesForCyclei){
        int cycleiSize = cyclei.size();
        for(int s = 0; s < cycleiSize; s++){
            //make a deep copy of this cycle
            UndirectedGraph<String, DefaultEdge> atomSubgraphTry = new SimpleGraph<>(DefaultEdge.class);
            Graphs.addGraph(atomSubgraphTry, atomSubgraph);
            List<String> cycleiDuplicate = new ArrayList<String>();
            cycleiDuplicate.clear();
            for(int i = 0; i < cycleiSize; i++){
                cycleiDuplicate.add(cyclei.get(i));
            }
            //start point vertex:cyclei.get(start point)
            String startpoint = cyclei.get(s);
            System.out.println("for cycle: " + cyclei.toString() + " This start is: " + startpoint);
            HashMap<String, String> thisStart = new HashMap<String, String>();
            //find the 2 neighbours of this start
            List<String> neighbrsOfS = new ArrayList<String>();
            for(String startpointneighbor: cycleiDuplicate){
                if(atomSubgraphTry.containsEdge(startpointneighbor, startpoint)){
                    neighbrsOfS.add(startpointneighbor);
                }
            }
            if(neighbrsOfS.size() != 2){
                System.out.println("Cant find the neighbors of the start vertex correctly in findAllTriangulations");
            }else{
                String neighbor1OfS = neighbrsOfS.get(0);
                String neighbor2OfS = neighbrsOfS.get(1);
                if(!(atomSubgraphTry.containsEdge(neighbor1OfS, neighbor2OfS))){
                    thisStart.put(neighbor1OfS, neighbor2OfS);
                    atomSubgraphTry.addEdge(neighbor1OfS, neighbor2OfS);
                    //take out the start vertex and carry on building on the rest
                    cycleiDuplicate.remove(s);
                    atomSubgraphTry.removeVertex(startpoint);
   
                    findcycles.givenStartFindTheRest(thisStart, neighbor1OfS, cycleiDuplicate, atomSubgraphTry, PossibilitiesForCyclei);
                    if(cycleiDuplicate.size() > 3){
                    findcycles.givenStartFindTheRest(thisStart, neighbor2OfS, cycleiDuplicate, atomSubgraphTry, PossibilitiesForCyclei);
                    }
                }else{
                    System.out.println("there was a chord between the neighs of the start point!");
                }
            }
        }
        return PossibilitiesForCyclei;
    }
    
    public static void givenStartFindTheRest(HashMap<String, String> thisStart, String startpoint, List<String> cyclei, UndirectedGraph<String, DefaultEdge> atomSubgraph, List<HashMap<String, String>> PossibilitiesForCyclei){
        if(cyclei.size() == 3){
            //there is no more options and hand submit the map as a unique(!) combination
            PossibilitiesForCyclei.add(thisStart);
            System.out.println("with this start the chords are: ");
            for (String v1: thisStart.keySet()){
                String v2 = thisStart.get(v1);
                System.out.println(v1 + " " + v2);
            }
        }else{
            UndirectedGraph<String, DefaultEdge> atomSubgraphTry = new SimpleGraph<>(DefaultEdge.class);
            Graphs.addGraph(atomSubgraphTry, atomSubgraph);
            List<String> cycleiDuplicate = new ArrayList<String>();
            cycleiDuplicate.clear();
            for(int i = 0; i < cyclei.size(); i++){
                cycleiDuplicate.add(cyclei.get(i));
            }
            //we can have 2 options with this start
            List<String> neighbrsOfS = new ArrayList<String>();
            for(String startpointneighbor: cycleiDuplicate){
                if(atomSubgraphTry.containsEdge(startpointneighbor, startpoint)){
                    neighbrsOfS.add(startpointneighbor);
                }
            }
            if(neighbrsOfS.size() != 2){
                System.out.println("Cant find the neighbors of the start vertex correctly in givenStartFindTheRest size is: " + neighbrsOfS.size());
            }else{
                String neighbor1OfS = neighbrsOfS.get(0);
                String neighbor2OfS = neighbrsOfS.get(1);
                if(!(atomSubgraphTry.containsEdge(neighbor1OfS, neighbor2OfS))){
                    thisStart.put(neighbor1OfS, neighbor2OfS);
                    atomSubgraphTry.addEdge(neighbor1OfS, neighbor2OfS);
                    //take out the start vertex and carry on building on the rest
                    cycleiDuplicate.remove(startpoint);
                    atomSubgraphTry.removeVertex(startpoint);
                    findcycles.givenStartFindTheRest(thisStart, neighbor1OfS, cycleiDuplicate, atomSubgraphTry, PossibilitiesForCyclei);
                    if(cycleiDuplicate.size() > 3){
                    findcycles.givenStartFindTheRest(thisStart, neighbor2OfS, cycleiDuplicate, atomSubgraphTry, PossibilitiesForCyclei);
                    }
                }else{
                    System.out.println("there was a chord between the neighs of the start point!");
                }
            }
        }
    }
    
    //reports the chordless cycles in side the atomic subgraph
    public static List<List<String>> findChordlessCycles(UndirectedSubgraph<String, DefaultEdge> atomSubgraph, ArrayList<Integer> label, List<String> vertices, int V, NeighborIndex comp, HashSet<Triplet<String, String, String>> tripletSet){
        List<List<String>> ccs = new ArrayList<List<String>>();
        ccs.clear();
        //initially keep all ccs as a potential
        Set<List<String>> paths = new HashSet<List<String>>();
        //add all triplets as initial paths
        for(Triplet t: tripletSet){
            //NB labels: u3>u1>u2
            String u1 = (String)t.getFirst();
            String u2 = (String)t.getSecond();
            String u3 = (String)t.getThird();
            List<String> tripletToPath = new ArrayList<String>();
            tripletToPath.add(u1);
            tripletToPath.add(u2);
            tripletToPath.add(u3);
            paths.add(tripletToPath);
        }
        
        ArrayList<Integer> blocked = new ArrayList<Integer>(V);
        for(int d = 0; d < V; d++){
            blocked.add(0);
        }
        
        Iterator iterator = paths.iterator();
        while (iterator.hasNext()){
            List<String> path = (List<String>)iterator.next();
            String u2 = path.get(1);
            findcycles.blockNeighbors(u2, blocked, vertices, atomSubgraph, comp);
            //visit u3
            findcycles.CCVisit(comp, path, blocked, vertices, label, u2, atomSubgraph);
            findcycles.unBlockNeighbors(u2, blocked, vertices, atomSubgraph, comp);
        }
        return ccs;
    }
    
    //Visit a path from the ut end.
    //if path could be closed retrun as a chordlesscycle, else immideately visit the possible extension
    public static void CCVisit(NeighborIndex comp, List<String> path, ArrayList<Integer> blocked,List<String> vertices, ArrayList<Integer> label, String u2, UndirectedSubgraph<String, DefaultEdge> atomSubgraph){
        List<List<String>> ccs = new ArrayList<List<String>>();
        System.out.println("open path is " + path.toString());
        String ut = path.get(path.size() - 1);
        String u1 = path.get(0);
        System.out.println("blocked neighs of " + ut);
        findcycles.blockNeighbors(ut, blocked, vertices, atomSubgraph, comp);
        Set<String> neighborsOfUt = comp.neighborsOf(ut);
        if(atomSubgraph.containsEdge(ut, u1)){
            //close off
            List<String> cc = new ArrayList<String>();
            cc = path;
            ccs.add(cc);
            System.out.println("Add to ccs: " + cc);
        }else{
            for(String v: neighborsOfUt){
                if(label.get(vertices.indexOf(v)) > label.get(vertices.indexOf(u2)) && (blocked.get(vertices.indexOf(v)) == 1)){
                    //extend the path
                    path.add(v);
                    
                    System.out.println("expanding path" + path + " with: " + v);
                    //immideately visit the extended path
                    findcycles.CCVisit(comp, path, blocked, vertices, label, u2, atomSubgraph);
                    
                }
            }
            System.out.println("Unblocked neighs of " + ut);
            findcycles.unBlockNeighbors(ut, blocked, vertices, atomSubgraph, comp);
        }
    }
    
    //block the neighbors of a given vertex
    //adds 1 to the blocked number of the neighbors of that vertex
    public static void blockNeighbors(String v, ArrayList<Integer> blocked,List<String> vertices, UndirectedSubgraph<String, DefaultEdge> atomSubgraph, NeighborIndex comp){
        Set<String> neighborsOfv = comp.neighborsOf(v);
        for(String s: neighborsOfv){
            int value = blocked.get(vertices.indexOf(s));
            value++;
            blocked.set(vertices.indexOf(s), value);
            System.out.println(s + "Has Block value increase " + value);
        }
    }
    
    //reverse function of the above
    public static void unBlockNeighbors(String v, ArrayList<Integer> blocked,List<String> vertices, UndirectedSubgraph<String, DefaultEdge> atomSubgraph, NeighborIndex comp){
        Set<String> neighborsOfv = comp.neighborsOf(v);
        for(String s: neighborsOfv){
            int value = blocked.get(vertices.indexOf(s));
            value--;
            blocked.set(vertices.indexOf(s), value);
            System.out.println(s + "Has Block value decrease" + value);
        }
    }
    
    // Method to label the vertices of graph by the degree labelling explained in Efficient enumeration of chordless cycles, Dias et al.
    //update 02 and uses a library function and uses smaller copies of the graph at each loop. proved to be faster.
    //returns null, but updates the global map of label
    public static ArrayList<Integer> label02(UndirectedSubgraph<String, DefaultEdge> atomSubgraph, int V, List<String> vertices){
        ArrayList<Integer> label = new ArrayList<Integer>(V);
        Boolean visited[] = new Boolean[V];
        for(int d = 0; d < V; d++){
            visited[d] = false;
            label.add(0);
        }
        UndirectedGraph<String, DefaultEdge> g0 = new SimpleGraph<>(DefaultEdge.class);
        Graphs.addGraph(g0, atomSubgraph);
        for(int i = 0; i < V; i++){
            Set <String> verticeSetOfG = g0.vertexSet();
            VertexDegreeComparator comp = new VertexDegreeComparator(g0);
            String labelledVertex = Collections.min(verticeSetOfG, comp);
            int thisLabelledVertex = vertices.indexOf(labelledVertex);
            label.set(thisLabelledVertex, i);
            visited[thisLabelledVertex] = true;
            g0.removeVertex(labelledVertex);
        }
        return label;
    }
    // Function to return the Triplets of possible initial chordlesspaths of graph g
    //triplets of form (u1,u2,u3) where u2<u1<u3 && u3 not adjacent to u1 && u1 and u3 adjacent to u2
    //update uses the triplet object
    //also uses a cache of adjacency
    public static HashSet<Triplet<String, String, String>> triplets(UndirectedSubgraph<String, DefaultEdge> atomSubgraph, int V, ArrayList<Integer> label, List<String> vertices,NeighborIndex comp){
        HashSet<Triplet<String, String, String>> tripletSet = new HashSet<Triplet<String, String, String>>();
        if(V > 3){
            for(int u = 0; u < V; u++){
                List<String> neighborsOfU = comp.neighborListOf(vertices.get(u));
                List<String> higherNeighborsOfU = new ArrayList<String>();
                //only keeping the nighbours with higher lables (lowering the amount of pair combinations
                for(int i = 0; i < neighborsOfU.size(); i++){
                    if(label.get(vertices.indexOf(neighborsOfU.get(i))) > label.get(u)){
                        higherNeighborsOfU.add(neighborsOfU.get(i));
                    }
                }
                int sizeOfNeighborsOfU = higherNeighborsOfU.size();
                if(!(sizeOfNeighborsOfU < 2)){
                    for(int x = 0; x < sizeOfNeighborsOfU; x++){
                        for(int y = x+1; y < sizeOfNeighborsOfU; y++){
                            //eliminate the redundant neighbour of a mid vertex u
                            
                            if(!atomSubgraph.containsEdge(higherNeighborsOfU.get(y), higherNeighborsOfU.get(x))){
                                //triplets: l(u3) > l(u1) && l(u2) is min
                                if(label.get(vertices.indexOf(higherNeighborsOfU.get(y))) > label.get(vertices.indexOf(higherNeighborsOfU.get(x)))){
                                    Triplet triplet = new Triplet(higherNeighborsOfU.get(x),vertices.get(u),higherNeighborsOfU.get(y));
                                    tripletSet.add(triplet);
                                }
                                else{
                                    Triplet triplet = new Triplet(higherNeighborsOfU.get(y),vertices.get(u),higherNeighborsOfU.get(x));
                                    tripletSet.add(triplet);
                                }
                            }else{//xuy was a triangle
                            }
                        }
                    }
                }else{//selected vertex u had less than 2 neighbors that had higher labels than it
                }
            }
        }else{System.out.println("Graph Contains less than 3 vertices and thus chordal");}
        
        if(tripletSet.size() != 0){
            for (Triplet temp : tripletSet) {
                System.out.println(temp.getFirst() + " " + temp.getSecond() + " " + temp.getThird());
            }
        }else{System.out.println("tripletset was null");}
        return tripletSet;
    }
    
    /**
     * Create a toy undirected graph based on String objects.
     *
     * @return a graph based on String objects.
     */
    private static UndirectedGraph<String, DefaultEdge> createUndirGraph(String pathToGraph)
    {
        UndirectedGraph<String, DefaultEdge> g = new SimpleGraph<>(DefaultEdge.class);
        try (BufferedReader reader =
             new BufferedReader(new FileReader(pathToGraph))) {
            String line = reader.readLine();
            int countLine = 0;
            countLine++;
            String VA = "";
            String VB = "";
            while(line !=null){
                for (int i = 0; i < line.length(); i++){
                    char c = line.charAt(i);
                    if( c == ' '){
                        //space seperator between each vertex in input
                        VA = line.substring(0, i);
                        VB = line.substring((i+1), line.length());
                        VB = VB.trim();
                        VA = VA.trim();
                        if( VA.length() != 0){
                            g.addVertex(VA);
                            g.addVertex(VB);
                            g.addEdge(VA, VB);
                            
                        }else{
                            break;
                        }
                    }
                }
                line = reader.readLine();            }
        }
        
        catch(IOException e) {
            System.out.println("Problem reading file in readAGraph");
        }
        return g;
    }}

