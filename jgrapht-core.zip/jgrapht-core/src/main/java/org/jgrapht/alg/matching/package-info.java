/**
 * Algorithms for the computation of matchings.
 */
package org.jgrapht.alg.matching;
