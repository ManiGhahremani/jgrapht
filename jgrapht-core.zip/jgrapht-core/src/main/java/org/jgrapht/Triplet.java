public class Triplet {
    private String first;
    private String second;
    private String third;
    
    public Triplet(String f, String s, String t) {
        first = f;
        second = s;
        third = t;
    }
    
    /*** setters and getters defined here ****/
    
}
